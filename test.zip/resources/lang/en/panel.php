<?php

return [
    'site_title' => 'dw',
];