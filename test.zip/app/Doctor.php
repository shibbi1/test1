<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\SoftDeletes;

class Doctor extends Model
{
    use SoftDeletes;

    public $table = 'doctors';

    protected $dates = [
        'created_at',
        'updated_at',
        'deleted_at',
    ];

    protected $fillable = [
        'name',
        'mobile',
        'created_at',
        'updated_at',
        'deleted_at',
        'services_id',
    ];

    public function services()
    {
        return $this->belongsTo(Service::class, 'services_id');
    }
}